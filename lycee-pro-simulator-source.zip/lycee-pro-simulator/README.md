# Lycée Pro Simulator — NumWorks N0120

Jeu C pour application externe NumWorks (format final attendu : `.nwa`).

## Jeu
- Choix d'un atelier : informatique, mécanique, électricité
- Mini-question par atelier
- Points de compétence, énergie et objectif diplôme

## Compilation depuis un Chromebook (sans installer de logiciel)
1. Créez un dépôt GitHub vide nommé `lycee-pro-simulator`.
2. Ajoutez tous les fichiers de cette archive en conservant les chemins.
3. Ouvrez l'onglet **Actions** et activez les workflows si GitHub le demande.
4. Lancez **Build Lycée Pro Simulator** avec **Run workflow**.
5. Si l'action passe au vert, ouvrez son exécution et téléchargez l'artefact `lycee-pro-simulator-nwa`.
6. Décompressez l'artefact si nécessaire, puis importez le `.nwa` sur https://my.numworks.com/apps.

Note : la compilation dépend du SDK `nwlink` et de l'outil ARM. Le fichier `.nwa` n'est créé que si l'action GitHub réussit. Cette archive contient les sources, pas un binaire précompilé.
