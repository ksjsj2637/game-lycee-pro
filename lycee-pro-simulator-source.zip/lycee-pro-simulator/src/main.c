#include <eadk.h>
#include <stdint.h>

const char eadk_app_name[] __attribute__((section(".rodata.eadk_app_name"))) = "Lycee Pro";
const uint32_t eadk_api_level __attribute__((section(".rodata.eadk_api_level"))) = 0;

#define WHITE 0xFFFF
#define BLACK 0x0000
#define NAVY  0x0841
#define GREEN 0x07E0
#define YELLOW 0xFFE0
#define RED 0xF800

static void fill(int x, int y, int w, int h, eadk_color_t c) {
  eadk_display_push_rect_uniform((eadk_rect_t){{x,y},{w,h}}, c);
}
static void text(const char *s, int x, int y, eadk_color_t fg, eadk_color_t bg) {
  eadk_display_draw_string(s, (eadk_point_t){x,y}, false, fg, bg);
}
static void screen(const char *title) {
  fill(0,0,320,240,NAVY);
  fill(0,0,320,26,BLACK);
  text("LYCEE PRO SIMULATOR", 8, 7, GREEN, BLACK);
  text(title, 8, 39, YELLOW, NAVY);
}
static void wait_ok(void) {
  while (!eadk_keyboard_key_down(eadk_keyboard_scan(), EADK_KEY_OK)) eadk_timing_msleep(25);
  while (eadk_keyboard_key_down(eadk_keyboard_scan(), EADK_KEY_OK)) eadk_timing_msleep(25);
}
static int wait_choice(void) {
  for (;;) {
    eadk_keyboard_state_t k = eadk_keyboard_scan();
    if (eadk_keyboard_key_down(k,EADK_KEY_ONE)) return 1;
    if (eadk_keyboard_key_down(k,EADK_KEY_TWO)) return 2;
    if (eadk_keyboard_key_down(k,EADK_KEY_THREE)) return 3;
    if (eadk_keyboard_key_down(k,EADK_KEY_OK)) return 0;
    eadk_timing_msleep(25);
  }
}
static void objectives(void) {
  screen("OBJECTIF : LE DIPLOME");
  text("Bienvenue en lycee pro !", 12, 68, WHITE, NAVY);
  text("Reussis les ateliers pratiques", 12, 94, WHITE, NAVY);
  text("Gagne des points de competence", 12, 116, WHITE, NAVY);
  text("Prepare ton stage en entreprise", 12, 138, WHITE, NAVY);
  text("Et decroche ton bac pro !", 12, 160, GREEN, NAVY);
  text("OK pour revenir", 12, 208, YELLOW, NAVY);
  wait_ok();
}
static void workshop(int branch) {
  const char *title = branch == 1 ? "ATELIER INFORMATIQUE" : branch == 2 ? "ATELIER MECANIQUE" : "ATELIER ELECTRICITE";
  const char *question = branch == 1 ? "Quel composant calcule ?" : branch == 2 ? "Quel outil serre un ecrou ?" : "Pour allumer une lampe, le circuit doit etre...";
  screen(title);
  text(question, 10, 72, WHITE, NAVY);
  if (branch == 1) text("1 CPU  2 Ecran  3 Souris",10,103,GREEN,NAVY);
  else if (branch == 2) text("1 Regle  2 Cle  3 Pinceau",10,103,GREEN,NAVY);
  else text("1 Ouvert  2 Coupe  3 Ferme",10,103,GREEN,NAVY);
  text("Choisis 1, 2 ou 3",10,137,WHITE,NAVY);
  int a = wait_choice();
  int correct = branch;
  screen("BILAN DE L'ATELIER");
  if (a == correct) {
    text("Bravo ! Bonne reponse.", 12, 82, GREEN, NAVY);
    text("+10 points de competence", 12, 110, WHITE, NAVY);
  } else {
    text("Rate cette fois !", 12, 82, RED, NAVY);
    text("Le prof te conseille de reviser.", 12, 110, WHITE, NAVY);
  }
  text("OK pour retourner au hall", 12, 205, YELLOW, NAVY);
  wait_ok();
}
int main(int argc, char *argv[]) {
  (void)argc; (void)argv;
  for (;;) {
    screen("LE HALL DU LYCEE");
    text("Choisis ton atelier :", 12, 65, WHITE, NAVY);
    text("1 - Informatique", 22, 91, WHITE, NAVY);
    text("2 - Mecanique", 22, 115, WHITE, NAVY);
    text("3 - Electricite", 22, 139, WHITE, NAVY);
    text("OK - Objectif du jeu", 22, 171, GREEN, NAVY);
    text("Utilise les touches 1, 2, 3", 12, 211, YELLOW, NAVY);
    int c = wait_choice();
    if (c == 0) objectives(); else workshop(c);
  }
  return 0;
}
